package com.example.joltfitnessapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginPage extends AppCompatActivity {

    //initializing the varibles
    EditText email, password;
    Button button;
    TextView reg;
    DatabaseHelper db;
    //declaring a global varibale
    public static String e;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_page);

        //type casting
        db = new DatabaseHelper(this);
       reg = findViewById(R.id.textView5);
       button = findViewById(R.id.button2);
       email = findViewById(R.id.mail);
       password = findViewById(R.id.password3);
       button.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               //giving the global varibale
               e = email.getText().toString();
               String p = password.getText().toString();

               //passing the information to the database
               Boolean checkEmailPass = db.emailPassword(e , p);
               // if true then go to the home page
               if(checkEmailPass==true)
               {
                   Intent click = new Intent(LoginPage.this, Home.class);
                   startActivity(click);
               }
               //error message for wrong password or email
               else
                   Toast.makeText(getApplicationContext(), "Wrong email or password", Toast. LENGTH_SHORT).show();
           }
       });


    }

    //going to register page
    public void toRegister(View view)
    {

        Intent click = new Intent(LoginPage.this, Register.class);
        startActivity(click);
    }
}
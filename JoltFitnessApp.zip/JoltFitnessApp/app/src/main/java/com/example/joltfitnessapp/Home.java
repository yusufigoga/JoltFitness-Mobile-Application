package com.example.joltfitnessapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class Home extends AppCompatActivity implements SensorEventListener {

    //initalizing the varibles
    Button home, profile, journal;
    TextView title, counter;
    public SensorManager sm;
    boolean activityRunning;
    ProgressBar pb;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        //calling the global varibale
        String email= LoginPage.e;

        //type casting
        home = findViewById(R.id.buttonHome);
        profile = findViewById(R.id.buttonProfile);
        journal = findViewById(R.id.buttonJournal);
        title = findViewById(R.id.tvHeading);
        counter = findViewById(R.id.tvStepsCounter);
        sm = (SensorManager)getSystemService(Context.SENSOR_SERVICE);



    }

    //while the programme is running
    @Override
    protected void onResume() {
        super.onResume();
        activityRunning = true;
        Sensor countSensor = sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);

        // check statement
        if(countSensor !=null)
        {
            sm.registerListener(this, countSensor,SensorManager.SENSOR_DELAY_UI);

        }
        else
        {
            Toast.makeText(this, "Sensor not found!!!", Toast.LENGTH_SHORT).show();
        }
    }
    //when the programme stops
    @Override
    protected void onPause() {
        super.onPause();
        activityRunning = false;
    }

    //to to profile
    public void toProfile(View view)
    {
        Intent click = new Intent(Home.this, Profile.class);

        startActivity(click);
    }

    //go to journal
    public void toJournal(View view)
    {
        Intent click = new Intent(Home.this, Journal.class);

        startActivity(click);
    }

    //goes to about page
    public void toAbout(View view)
    {
        Intent click = new Intent(Home.this, About.class);

        startActivity(click);
    }

    //go to graph page
    public void toGraph(View view)
    {
        Intent click = new Intent(Home.this, Graph.class);

        startActivity(click);
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {

        // display the # of steps
        counter.setText(String.valueOf(sensorEvent.values[0]));

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }
}
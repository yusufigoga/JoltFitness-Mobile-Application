package com.example.joltfitnessapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class About extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);
    }

    //go to home page
    public void toHome(View view)
    {
        Intent click = new Intent(About.this, Home.class);
        startActivity(click);
    }
}
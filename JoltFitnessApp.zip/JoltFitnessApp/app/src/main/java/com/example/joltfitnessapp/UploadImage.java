package com.example.joltfitnessapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

public class UploadImage extends AppCompatActivity {

    //initializing the varible
    Button image, save, cancel;
    EditText weight, calorie, date, meal;
    ImageView i;
    DatabaseHelper db;

    final int REQUEST_CODE_GALLERY = 999;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_image);

        //calling the db from Databasehelper
        db = new DatabaseHelper(this);
        //type casting
        image = findViewById(R.id.buttonCamera);
        save = findViewById(R.id.buttonSave);
        cancel = findViewById(R.id.button9);

        weight = findViewById(R.id.weightChange);
        calorie = findViewById(R.id.calorieToday);
        date = findViewById(R.id.Dt);
        meal = findViewById(R.id.meal);

        i = findViewById(R.id.imageView3);

        //when image button is pressed it asks for permission from phone and accesses the gallery
        image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ActivityCompat.requestPermissions(
                        UploadImage.this,
                        new String[] {Manifest.permission.READ_EXTERNAL_STORAGE},
                        REQUEST_CODE_GALLERY
                );
            }
        });

        //when the save button is pressed then it adds the information to the database
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String email= LoginPage.e;

                    Boolean check =
                      db.insertJournal(email,
                      Double.parseDouble(weight.getText().toString()),
                      Double.parseDouble(calorie.getText().toString()),
                      date.getText().toString(),
                      meal.getText().toString());
                    if(check == true)
                    {
                        Toast.makeText(getApplicationContext(), "Entry Added to Journal", Toast. LENGTH_SHORT).show();
                        Intent click = new Intent(UploadImage.this, Journal.class);
                        startActivity(click);
                    }
                    else{
                        Toast.makeText(getApplicationContext(), "Entry not added ", Toast. LENGTH_SHORT).show();
                    }




            }
        });


    }

    //chnaging image to byte
    private byte[] imageViewToByte(ImageView i){
        Bitmap bitmap = ((BitmapDrawable)i.getDrawable()).getBitmap();
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
        byte[] byteArray = stream.toByteArray();
        return byteArray;
    }

    //asks for permission
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        if(requestCode == REQUEST_CODE_GALLERY){
            if(grantResults.length >0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                Intent intent = new Intent(Intent.ACTION_PICK);
                intent.setType("image/*");
                startActivityForResult(intent, REQUEST_CODE_GALLERY);
            }
            else{
                Toast.makeText(getApplicationContext(), "You do not have permission to access file location!", Toast.LENGTH_SHORT).show();
            }
            return;
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        if(requestCode == REQUEST_CODE_GALLERY && resultCode == RESULT_OK && data != null){
            Uri uri = data.getData();

            try {
                InputStream inputStream = getContentResolver().openInputStream(uri);
                Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                i.setImageBitmap(bitmap);
            }catch (FileNotFoundException e){
                e.printStackTrace();
            }
        }

        super.onActivityResult(requestCode, resultCode, data);
    }

    //go to journal page
    public void toJournal(View view)
    {

        Intent click = new Intent(UploadImage.this, Journal.class);
        startActivity(click);
    }
}
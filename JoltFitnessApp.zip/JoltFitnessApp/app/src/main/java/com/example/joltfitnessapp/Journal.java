package com.example.joltfitnessapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class Journal extends AppCompatActivity {

    //initializing the varibales
    Button home, profile, journal, view;
    DatabaseHelper db;
    ListView list;
    ArrayList<String> listItem;
    ArrayAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_journal);

        //calling the database
        db = new DatabaseHelper(this);

        listItem = new ArrayList<>();

       //type casting
        home = findViewById(R.id.buttonHome4);
        profile = findViewById(R.id.button5);
        journal = findViewById(R.id.button3);
        list = findViewById(R.id.users_list);

    //calling the method from below
        ViewData();

        //when item is clicked on show a toast of that information
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String text = list.getItemAtPosition(i).toString();
                Toast.makeText(Journal.this, "" + text, Toast. LENGTH_SHORT).show();

            }
        });


    }

    private void ViewData() {
        //calling the global variable
        String email= LoginPage.e;

        //calling the cursor from Databasehelper
        Cursor cursor = db.getData(email);

    //checking to see if there is any data in the table
        if(cursor.getCount() == 0){
            Toast.makeText(getApplicationContext(), "No data to show", Toast. LENGTH_SHORT).show();
        }
        //if there is data they show it in the list view
        else{
        int count = 1;
        while(cursor.moveToNext()){
            listItem.add("Journal Entry " + count);
            listItem.add("Date  : " + cursor.getString(3));
            listItem.add("Weight: " +cursor.getString(1));
            listItem.add("Calorie: " +cursor.getString(2));
            listItem.add("Meal: " +cursor.getString(4));
            count++;


        }
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listItem);
        list.setAdapter(adapter);

        }

    }

    //go to home page
    public void toHome(View view)
    {
        Intent click = new Intent(Journal.this, Home.class);
        startActivity(click);
    }
    //go to profile page
    public void toProfile(View view)
    {
        Intent click = new Intent(Journal.this, Profile.class);
        startActivity(click);
    }
    //go to upload page
    public void toUpload(View view)
    {

        Intent click = new Intent(Journal.this, UploadImage.class);
        startActivity(click);
    }
}
package com.example.joltfitnessapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;

public class Register extends AppCompatActivity {

    //initialzing varibles
    EditText name, surname, email, password, weight, height, weightGoal, CalorieIntake;
    Button registerBtn;
    RadioButton imperial, metric;
    TextView log;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        //calling the db from Databasehelper
        db = new DatabaseHelper(this);

        //type casting
        log = findViewById(R.id.textView4);
        name = findViewById(R.id.fullName);
        surname = findViewById(R.id.Surname);
        email = findViewById(R.id.mail);
        password = findViewById(R.id.Password);
        registerBtn = findViewById(R.id.button);
        weight = findViewById(R.id.weight);
        height = findViewById(R.id.height);
        weightGoal = findViewById(R.id.weightGoal);
        CalorieIntake = findViewById(R.id.calorie);
        imperial = findViewById(R.id.imperial);
        metric = findViewById(R.id.metric);

        try {
            //if register button is clicked
            registerBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    //making the textboxes = to a varible
                    String s1 = email.getText().toString();
                    String s2 = password.getText().toString();
                    String s3 = name.getText().toString();
                    String s4 = surname.getText().toString();
                    Double s5 = Double.parseDouble(weight.getText().toString());
                    Double s6 = Double.parseDouble(height.getText().toString());
                    Double s7 = Double.parseDouble(weightGoal.getText().toString());
                    Double s8 = Double.parseDouble(CalorieIntake.getText().toString());

                    //if no information in the textboxes then give error message
                    if (s1.equals("") || s2.equals("") || s3.equals("") || s4.equals("") || s5.equals("") || s6.equals("") || s7.equals("") || s8.equals("")) {
                        Toast.makeText(getApplicationContext(), "Fields are empty", Toast.LENGTH_SHORT).show();
                    } else {
                        //if the email is correct
                        Boolean check = db.check(s1);
                        if (check == true) {
                            //if metric radiobutton is clicked
                            if (metric.isChecked()) {

                                //putting email and password into the database
                                Boolean insert = db.insert(s1, s2);
                                //putting all the informstion into the info table
                                Boolean insertInfo = db.insertInfo(s1, s3, s4, s5, s6, "m", "kg", s7, s8);
                                //if values for both tables are inserted then
                                if (insert == true && insertInfo == true) {
                                    Toast.makeText(getApplicationContext(), "Registered Successfully", Toast.LENGTH_SHORT).show();
                                    Intent click = new Intent(Register.this, LoginPage.class);
                                    startActivity(click);
                                }

                            }
                            //if the imperial radiobutton is clicked
                            else if (imperial.isChecked()) {
                                //putting email and password into the database
                                Boolean insert = db.insert(s1, s2);
                                //putting all the informstion into the info table
                                Boolean insertInfo = db.insertInfo(s1, s3, s4, s5, s6, "inches", "pounds", s7, s8);
                                //if values for both tables are inserted then
                                if (insert == true && insertInfo == true) {
                                    Toast.makeText(getApplicationContext(), "Registered Successfully", Toast.LENGTH_SHORT).show();
                                    Intent click = new Intent(Register.this, LoginPage.class);
                                    startActivity(click);
                                }
                            }

                        } else {
                            Toast.makeText(getApplicationContext(), "User already exists!!!", Toast.LENGTH_SHORT).show();
                        }
                    }


                }
            });

        }catch(Exception e){
            e.printStackTrace();
        }
    }

    //go to login page
    public void toLogin(View view)
    {
        Intent click = new Intent(Register.this, LoginPage.class);
        startActivity(click);
    }
}
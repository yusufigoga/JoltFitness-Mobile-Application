package com.example.joltfitnessapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.BarGraphSeries;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.util.ArrayList;

public class Graph extends AppCompatActivity {

    //declaring varibales
    BarChart graph;
    DatabaseHelper db;
    String temp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_graph);

        //calling the database
        db = new DatabaseHelper(this);

        //calling the global variable
        String email = LoginPage.e;

        //calling the cursor from Databasehelper
        Cursor cursor = db.getData(email);

        //type casting
        graph = findViewById(R.id.graph);

        //creating a temporary arraylist
        ArrayList<BarEntry> weight = new ArrayList<>();
        float count = 1f;
        //looping throught te database to get all entries and put it into temporary arraylist
        while (cursor.moveToNext()) {
            weight.add(new BarEntry(count, Float.parseFloat(cursor.getString(1))));
            count++;
        }

        //putting the information into graph
        BarDataSet barDataSet = new BarDataSet(weight, "Weight Change in Grams");

        //customization of graph
        barDataSet.setColors(ColorTemplate.MATERIAL_COLORS);
        barDataSet.setValueTextColor(Color.BLACK);
        barDataSet.setValueTextSize(16f);

        BarData barData = new BarData(barDataSet);

        graph.setFitBars(true);
        graph.setData(barData);
        graph.getDescription().setText("Weight");
        graph.animateY(2000);



    }
    //go to home page
    public void toHome(View view)
    {
        Intent click = new Intent(Graph.this, Home.class);
        startActivity(click);
    }
}
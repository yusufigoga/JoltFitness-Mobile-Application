package com.example.joltfitnessapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {


    //set duration for splash screen
    long Delay = 8000;

    //varibales
    ImageView imgV;
   

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imgV = findViewById(R.id.imageView);
        //create timer
        Timer RunSplash = new Timer();

        //Task to do when the timer ends
        TimerTask showSplash  = new TimerTask()
        {
            @Override
            public void run() {
                //close splash
                finish();

                //start second screen or login screen
                Intent firstIntent = new Intent(MainActivity.this, LoginPage.class);
                startActivity(firstIntent);

            }
        };

        //start the timer
        RunSplash.schedule(showSplash, Delay);
    }
}
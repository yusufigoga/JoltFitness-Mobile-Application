package com.example.joltfitnessapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class Profile extends AppCompatActivity {

    //initalizing varibales
    EditText name, surname, weight, height, weightGoal, h1, w1, wg1;
    Button home, profile, journal, update;
    RadioButton imperial, metric;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        //calling the global varibale
        String email= LoginPage.e;
        //connecting to Databasehelper
        db = new DatabaseHelper(this);

        //type casting
        home = findViewById(R.id.buttonHome2);
        profile = findViewById(R.id.button5);
        journal = findViewById(R.id.buttonJournal4);
        update = findViewById(R.id.button6);

        name = findViewById(R.id.plainName);
        surname = findViewById(R.id.plainSurname);
        weight = findViewById(R.id.weightPlain);
        height = findViewById(R.id.heightPlain);
        weightGoal = findViewById(R.id.WeightGoalProfile);
        h1 = findViewById(R.id.h);
        w1 = findViewById(R.id.w);
        wg1 = findViewById(R.id.wg);

        imperial = findViewById(R.id.imperial);
        metric =  findViewById(R.id.metric);

        //trying to see if the code below works
        try {
            //giving each column in the database a varible
            Cursor cursor = db.insertProfile(email);
            cursor.moveToPosition(0);
            String nam = cursor.getString(1);
            String sur = cursor.getString(2);
            String het = cursor.getString(3);
            String Wet = cursor.getString(4);
            String h = cursor.getString(5);
            String w = cursor.getString(6);
            String Goal = cursor.getString(7);


            if (!cursor.isClosed()) {
                cursor.close();
            }

            //adding the information from the database into the textboxes
            name.setText(nam);
            surname.setText(sur);
            weight.setText(het);
            height.setText(Wet);
            weightGoal.setText(Goal);
            h1.setText(h);
            h1.setClickable(false);
            h1.setFocusable(false);
            w1.setText(w);
            w1.setClickable(false);
            w1.setFocusable(false);
            wg1.setText(w);
            wg1.setFocusable(false);
            wg1.setClickable(false);


            //catching the error so the application doesnt crash
        }catch (Exception e){

            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
             }

        //when the update button is clicked do this below
        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //calling the global variable
                String email= LoginPage.e;
                //giving the text from the textboxes = to a varibale
                String s1 = name.getText().toString();
                String s2 = surname.getText().toString();
                Double s3 = Double.parseDouble(weight.getText().toString());
                Double s4 = Double.parseDouble(height.getText().toString());
                Double s5 = Double.parseDouble(weightGoal.getText().toString());

                //updating information in the database
                Boolean update = db.updateProfile(email, s1,s2,s3,s4,s5);
                if (s1.equals("") || s2.equals("") || s3.equals("") || s4.equals("") || s5.equals("") )
                {
                    Toast.makeText(getApplicationContext(), "Fields are empty", Toast. LENGTH_SHORT).show();
                }
                //if the update works show this messeage and refresh the page
                if(update==true){
                    Toast.makeText(getApplicationContext(), "Update Successfully", Toast. LENGTH_SHORT).show();
                    finish();
                    startActivity(getIntent());
                }
                //else we saying update was no successful
                else{
                    Toast.makeText(getApplicationContext(), "Update Unsuccessful", Toast. LENGTH_SHORT).show();
                }
            }
        });

    }

    //go to home page
    public void toHome(View view)
    {
        Intent click = new Intent(Profile.this, Home.class);
        startActivity(click);
    }

    //go to journal page
    public void toJournal(View view)
    {
        Intent click = new Intent(Profile.this, Journal.class);
        startActivity(click);
    }
}
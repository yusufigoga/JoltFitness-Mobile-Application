package com.example.joltfitnessapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    //initialze variable name for the database
    private static final String DATABASE_NAME = "JoltFitnessDb";

    //creating the database
    DatabaseHelper(Context context){
        super(context, DATABASE_NAME, null,1);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        //creating tables in the database
        db.execSQL("Create table login(email text primary key, password text)");
        db.execSQL("Create table info(email text primary key, name text, surname text, weight real, height real, hType text, wType text, wGoal real, calGoal real)");
        db.execSQL("Create table picture(email text, wChange real, calorie real, date text, meal text )");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        //dropping tables if they already exists
       db.execSQL("drop table if exists login");
        db.execSQL("drop table if exists info");
        db.execSQL("drop table if exists picture ");

    }

    //inserting information into the picture table
    public Boolean insertJournal(String email, Double wChange, Double calorie, String date, String meal ){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues1 = new ContentValues();
        contentValues1.put("email", email);
        contentValues1.put("wChange", wChange);
        contentValues1.put("calorie", calorie);
        contentValues1.put("date", date);
        contentValues1.put("meal", meal);
        long ins = db.insert("picture", null, contentValues1);
        if(ins==-1) return false;
        else return  true;
    }

    //getting data from the picture table
    public Cursor getData(String email){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("select * from picture where email = '" + email + "'",null);
        return cursor;
    }

    //inserting in email and password into login table
    public boolean insert(String email, String password){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("email", email);
        contentValues.put("password", password);
        long ins = db.insert("login", null, contentValues);
        if(ins==-1) return false;
        else return  true;
    }

    //inserting into the info table
    public boolean insertInfo(String email, String name, String surname, Double weight, Double height, String hType, String wType, Double wGoal, Double calGoal){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues1 = new ContentValues();
        contentValues1.put("email", email);
        contentValues1.put("name", name);
        contentValues1.put("surname", surname);
        contentValues1.put("weight", weight);
        contentValues1.put("height", height);
        contentValues1.put("hType", hType);
        contentValues1.put("wType", wType);
        contentValues1.put("wGoal", wGoal);
        contentValues1.put("calGoal", calGoal);
        long ins = db.insert("info", null, contentValues1);
        if(ins==-1) return false;
        else return  true;
    }

    //chekcing if email exixts
    public Boolean check(String email){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("Select * from login where email =?", new String[]{email});
        if(cursor.getCount() >0) return false;
        else return true;
    }

    //checking the email and password
    public Boolean emailPassword(String email, String password)
    {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from login where email=? and password=?", new String[]{email,password});
        if(cursor.getCount()>0) return true;
        else return false;
    }

    //calling the data from the info table
    public Cursor insertProfile(String email){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("select * from info where email = '" + email + "'",null);
        return cursor;
    }

    //updating user profile
    public Boolean updateProfile(String email, String name, String surname, Double weight, Double height,Double wGoal)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues1 = new ContentValues();
        contentValues1.put("name", name);
        contentValues1.put("surname", surname);
        contentValues1.put("weight", weight);
        contentValues1.put("height", height);
        contentValues1.put("wGoal", wGoal);
        long ins = db.update("info", contentValues1, "email = '" + email + "'", null);
        if(ins==-1) return false;
        else return  true;

    }
}
